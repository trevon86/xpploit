### NekoBotV1Rev | Auto Exploiter With 500+ Exploit 2000+ Shell 
![Screenshoot](https://github.com/tegal1337/NekoBotV1/blob/master/scrot_2021-04-01-41_680x362.png)<br>
For Old version [NekobotV1](https://github.com/tegal1337/NekoBotV1-old)<br>
NekoBotV1Rev is an auto exploit tool to facilitate the penetration of one or many websites (Wordpress, Joomla, Drupal, Magento, Opencart,and Etc). 
<br>
#### Features :
[+] Wordpress :
<pre>
1- Cherry-Plugin
2- download-manager Plugin
3- wysija-newsletters
4- Slider Revolution [Revslider]
5- gravity-forms
6- userpro
7- wp-gdpr-compliance
8- wp-graphql
9- formcraft
10- Headway
11- Pagelines Plugin
12- WooCommerce-ProductAddons
13- CateGory-page-icons
14- addblockblocker
15- barclaycart
16- Wp 4.7 Core Exploit
17- eshop-magic
18- HD-WebPlayer
19- WP Job Manager
20- wp-miniaudioplayer
21- wp-support-plus
22- ungallery Plugin
23- WP User Frontend
24- Viral-options
25- Social Warfare
26- jekyll-exporter
27- cloudflare plugin
28- realia plugin
29- woocommerce-software
30- enfold-child Theme
31- contabileads plugin
32- prh-api plugin
33- dzs-videogallery plugin
34- mm-plugin
35- Wp-Install
36- Auto BruteForce
</pre>
[+] Joomla
<pre>
1- Com_adsmanager
2- Com_alberghi
3- Com_CCkJseblod
4- Com_extplorer
5- Com_Fabric
6- Com_facileforms
7- Com_Hdflvplayer
8- Com_Jbcatalog
9- Com_JCE
10- Com_jdownloads
11- Com_Joomanager
12- Com_Macgallery
13- Com_media
14- Com_Myblog
15- Com_rokdownloads
16- Com_s5_media_player
17- Com_SexyContactform
18- Joomla core 3.x RCE
19- Joomla core 3.x RCE [2019]
20 - Joomla Core 3.x Admin Takeover
21 - Auto BruteForce
22 - Com_b2jcontact
23 - Com_bt_portfolio
24 - Com_civicrm
25 - Com_extplorer
26 - Com_facileforms
27 - Com_FoxContent
28 - Com_jwallpapers
29 - Com_oziogallery
30 - Com_redmystic
31 - Com_simplephotogallery
32 - megamenu module
33 - mod_simplefileuploadv1
</pre>
[+] Drupal :
<pre>
1- Drupal Add admin geddon1
2- Drupal RCE geddon2
3- Drupal 8 RCE RESTful
4- Drupal mailchimp
5- Drupal php-curl-class
6- BruteForce
7- Drupal SQL Add Admin
8- Drupal 7 RCE
9- bartik
10- Avatarafd Config
11- Drupal 8
12- Drupal Default UserPass
</pre>
[+] Magento :
<pre>
1- Shoplift
2- Magento Default user pass
</pre>
[+] Oscommerce
<pre>
1- OsCommerce Core 2.3 RCE Exploit
opencart
</pre>
[+] OTHER :
<pre>
1- Env Exploit
2- SMTP CRACKER
3- CV
</pre>
