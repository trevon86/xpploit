# Cpanel Checker

 Free cpanel checker tool for you + 50 free cpanels 

Your file should look like this :

`https://example.com|username|password`


<a href="https://github.com/esfelurm/cpanel-checker/blob/main/Cpanel%20Free/50%20cpanel.txt">Download Cpanel File free</a>


# install

```
git clone https://github.com/esfelurm/cpanel-checker
cd cpanel-checker
python cpanel-checker.py
```
Bot's : Below 1000 

input : Cpanel Free/50 cpanel.txt
